package MordorsCrueltyPlan.Foods;

public class Mushrooms extends Food{

    public Mushrooms() {
        super(-10);
    }
}
