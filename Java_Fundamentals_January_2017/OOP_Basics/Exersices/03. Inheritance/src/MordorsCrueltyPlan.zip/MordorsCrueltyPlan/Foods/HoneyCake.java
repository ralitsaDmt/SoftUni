package MordorsCrueltyPlan.Foods;

public class HoneyCake extends Food{

    public HoneyCake() {
        super(5);
    }
}
