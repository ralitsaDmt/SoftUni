package MordorsCrueltyPlan.Foods;

public class OtherFood extends Food{

    public OtherFood() {
        super(-1);
    }
}
