package MordorsCrueltyPlan.Foods;

public class Apple extends Food{

    public Apple() {
        super(1);
    }
}
