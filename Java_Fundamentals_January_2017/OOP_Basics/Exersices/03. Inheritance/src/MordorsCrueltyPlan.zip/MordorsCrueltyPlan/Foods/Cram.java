package MordorsCrueltyPlan.Foods;

public class Cram extends Food{

    public Cram() {
        super(2);
    }
}
