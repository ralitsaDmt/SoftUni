package MordorsCrueltyPlan.Foods;

public class Lembas extends Food{

    public Lembas() {
        super(3);
    }
}
