package MordorsCrueltyPlan.Moods;

public class Mood {

    @Override
    public String toString() {
        return this.getClass().getSimpleName();
    }
}
