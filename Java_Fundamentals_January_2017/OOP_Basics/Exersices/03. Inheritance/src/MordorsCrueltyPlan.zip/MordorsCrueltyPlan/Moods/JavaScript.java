package MordorsCrueltyPlan.Moods;

/**
 * Created by redel on 28.2.2017 г..
 */
public class JavaScript extends Mood {
}
