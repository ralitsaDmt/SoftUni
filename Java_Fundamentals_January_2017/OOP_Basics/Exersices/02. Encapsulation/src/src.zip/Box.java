public class Box {

    private Double length;
    private Double width;
    private Double height;

    public void setWidth(Double width) {
        this.width = width;
    }

    public void setHeight(Double height) {
        this.height = height;
    }

    public void setLength(Double length) {

        this.length = length;
    }

    public Double getLength() {

        return length;
    }

    public Double getWidth() {
        return width;
    }

    public Double getHeight() {
        return height;
    }

    public Double surfaceArea(){
        return 2 * (length * height + height * width + width * length);
    }

    public Double lateralArea(){
        return 2.0 * this.height * (this.width + this.length);
    }

    public Double volume(){
        return this.height * this.length * this.width;
    }
}
