package WildFarm_03.Animals;

public abstract class Feline extends Mammal {

    public Feline(String name, String type, double weight, String region){
        super(name, type, weight, region);
    }
}
