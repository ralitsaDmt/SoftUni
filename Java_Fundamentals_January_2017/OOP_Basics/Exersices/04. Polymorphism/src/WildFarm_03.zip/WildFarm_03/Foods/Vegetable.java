package WildFarm_03.Foods;

public class Vegetable extends Food {

    public Vegetable(int quantity){
        super(quantity);
    }
}
