package systemsplit.components;

public enum ComponentTypes {
    HARDWARE,
    SOFTWARE,
    Power,
    Heavy,
    Express,
    Light
}
