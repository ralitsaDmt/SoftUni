package Problem_02_CarShop;

public interface Sellable extends Car {
    double PRICE = 0;

    double getPrice();
}
