package Problem_03_SayHello;

public interface Person {
    String getName();

    String sayHello();
}
