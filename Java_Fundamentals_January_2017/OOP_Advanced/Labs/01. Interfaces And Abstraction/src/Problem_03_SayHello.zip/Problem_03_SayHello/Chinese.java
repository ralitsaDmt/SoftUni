package Problem_03_SayHello;

public class Chinese extends BasePerson {

    @Override
    public String sayHello() {
        return "Djydjybydjy";
    }

    public Chinese(String name) {
        super(name);
    }
}
