package Problem_03_CoffeMachine;

public interface CoffeMachine {

    void buyCoffee(String size, String type);

    void insertCoin(String coin);

    Iterable<Coffee> coffeesSold();
}
