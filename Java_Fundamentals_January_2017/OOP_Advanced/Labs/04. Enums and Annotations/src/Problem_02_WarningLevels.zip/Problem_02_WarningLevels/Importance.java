package Problem_02_WarningLevels;

public enum Importance {

    LOW,
    NORMAL,
    MEDIUM,
    HIGH;

}
