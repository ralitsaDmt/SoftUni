package Problem_06_BirthdayCelebrations;

public interface Identifiable {
    String getId();
}
