package Problem_06_BirthdayCelebrations;

public interface Birthable {

    String getName();

    String getBirthdate();
}
