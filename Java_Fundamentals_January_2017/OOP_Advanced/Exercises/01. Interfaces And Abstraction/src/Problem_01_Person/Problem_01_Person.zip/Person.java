package Problem_01_Person;

public interface Person {

    //void setName(String name);

    String getName();

    //void setAge(int age);

    int getAge();
}
