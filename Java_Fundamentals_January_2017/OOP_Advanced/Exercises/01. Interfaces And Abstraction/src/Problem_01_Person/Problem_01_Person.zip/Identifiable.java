package Problem_01_Person;

public interface Identifiable {

    String getId();
}
