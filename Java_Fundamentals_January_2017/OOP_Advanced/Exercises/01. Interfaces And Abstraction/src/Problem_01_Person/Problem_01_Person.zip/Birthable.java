package Problem_01_Person;

public interface Birthable {
    String getBirthdate();
}
