package Problem_03_Ferrari;

public interface Car {

    String useBrakes();

    String pushGasPedal();
}
