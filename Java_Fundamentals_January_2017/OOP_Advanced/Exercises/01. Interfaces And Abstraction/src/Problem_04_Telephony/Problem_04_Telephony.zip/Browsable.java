package Problem_04_Telephony;

public interface Browsable {
    void browse(String website);
}
