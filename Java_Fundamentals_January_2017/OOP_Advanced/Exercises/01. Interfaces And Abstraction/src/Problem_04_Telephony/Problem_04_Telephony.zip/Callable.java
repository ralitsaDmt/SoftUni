package Problem_04_Telephony;

public interface Callable {
    void call(String number);
}
