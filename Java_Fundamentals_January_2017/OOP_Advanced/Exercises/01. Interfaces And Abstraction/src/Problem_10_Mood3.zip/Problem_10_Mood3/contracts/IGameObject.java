package Problem_10_Mood3.contracts;

public interface IGameObject {

    String getUserName();

    String getPassword();

    int getLevel();
}
