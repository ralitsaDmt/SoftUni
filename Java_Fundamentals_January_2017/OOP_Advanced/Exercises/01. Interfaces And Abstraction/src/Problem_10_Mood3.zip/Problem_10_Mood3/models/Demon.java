package Problem_10_Mood3.models;

public class Demon extends GameObject<Integer, Double> {

    public Demon(String username, Integer hashedPassword, Double specialPoints, int level) {
        super(username, hashedPassword, specialPoints, level);
    }

    public Double getEnergy(){
        return this.getSpecialPoints();
    }
}
