package Problem_10_Mood3.models;

public class Archangel extends GameObject<String, Integer> {

    public Archangel(String username, String hashedPassword, Integer specialPoints, int level) {
        super(username, hashedPassword, specialPoints, level);
    }

    public int getMana(){
        return this.getSpecialPoints();
    }
}
