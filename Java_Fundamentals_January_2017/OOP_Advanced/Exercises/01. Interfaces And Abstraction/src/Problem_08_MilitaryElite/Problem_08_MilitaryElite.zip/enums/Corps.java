package Problem_08_MilitaryElite.enums;

public enum Corps {
    Airforces, Marines
}
