package Problem_08_MilitaryElite.enums;

public enum MissionStates {
    inProgress, Finished
}
