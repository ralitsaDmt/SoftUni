package Problem_08_MilitaryElite.contracts.Soldiers;

public interface ISoldier {
    public int getId();

    public String getFirstName();

    public String getLastName();
}
