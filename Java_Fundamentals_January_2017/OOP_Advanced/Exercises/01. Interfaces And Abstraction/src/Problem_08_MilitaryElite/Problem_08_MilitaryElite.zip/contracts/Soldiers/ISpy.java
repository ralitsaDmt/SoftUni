package Problem_08_MilitaryElite.contracts.Soldiers;

public interface ISpy {
    int getCodeNumber();
}
