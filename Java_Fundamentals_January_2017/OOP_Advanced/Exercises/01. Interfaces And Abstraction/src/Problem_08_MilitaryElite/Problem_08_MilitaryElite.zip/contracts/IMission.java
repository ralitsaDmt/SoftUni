package Problem_08_MilitaryElite.contracts;

public interface IMission {

    String getCodeName();

    String getState();

    void completeMission();
}
