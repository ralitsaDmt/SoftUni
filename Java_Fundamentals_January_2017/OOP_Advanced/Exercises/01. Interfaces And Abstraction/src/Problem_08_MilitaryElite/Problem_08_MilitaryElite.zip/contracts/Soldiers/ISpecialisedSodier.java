package Problem_08_MilitaryElite.contracts.Soldiers;

public interface ISpecialisedSodier {
    String getCorps();
}
