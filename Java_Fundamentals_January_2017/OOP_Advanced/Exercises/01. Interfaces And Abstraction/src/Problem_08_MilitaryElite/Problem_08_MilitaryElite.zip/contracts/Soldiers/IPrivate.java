package Problem_08_MilitaryElite.contracts.Soldiers;

public interface IPrivate {
    public double getSalary();
}
