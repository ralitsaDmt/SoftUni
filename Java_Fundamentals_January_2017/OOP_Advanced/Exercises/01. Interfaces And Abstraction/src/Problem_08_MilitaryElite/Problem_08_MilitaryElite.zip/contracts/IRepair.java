package Problem_08_MilitaryElite.contracts;

public interface IRepair {
    String getName();

    int gethoursWorked();
}
