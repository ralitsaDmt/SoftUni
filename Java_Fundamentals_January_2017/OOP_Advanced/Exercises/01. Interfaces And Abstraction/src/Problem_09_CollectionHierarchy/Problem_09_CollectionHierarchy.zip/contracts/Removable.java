package Problem_09_CollectionHierarchy.contracts;

public interface Removable extends Addable {

    String remove();
}
