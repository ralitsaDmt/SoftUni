package Problem_09_CollectionHierarchy.contracts;

public interface Addable {
    int add(String item);
}
