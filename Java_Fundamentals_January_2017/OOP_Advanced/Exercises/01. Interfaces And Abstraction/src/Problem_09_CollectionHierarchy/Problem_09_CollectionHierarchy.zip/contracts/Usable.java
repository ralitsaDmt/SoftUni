package Problem_09_CollectionHierarchy.contracts;

public interface Usable extends Removable {

    int getUsedElements();
}
