package P10_InfernoInfinity.enums;

public enum WeaponType {
    AXE, SWORD, KNIFE;
}
