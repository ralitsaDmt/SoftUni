package P10_InfernoInfinity.models;

public class Knife extends Weapon {

    public Knife(String name) {
        super(name, 2, 3, 4);
    }
}
