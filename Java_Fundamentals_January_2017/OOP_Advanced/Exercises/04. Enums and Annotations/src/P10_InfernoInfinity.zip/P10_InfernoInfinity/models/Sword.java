package P10_InfernoInfinity.models;

public class Sword extends Weapon {

    public Sword(String name) {
        super(name, 3, 4, 6);
    }
}
