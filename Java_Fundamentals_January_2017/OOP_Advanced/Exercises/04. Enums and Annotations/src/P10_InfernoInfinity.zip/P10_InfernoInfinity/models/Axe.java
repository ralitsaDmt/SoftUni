package P10_InfernoInfinity.models;

public class Axe extends Weapon {

    public Axe(String name) {
        super(name, 4, 5, 10);
    }
}
