package P02_CardRank;

import P01_CardSuits.Suits;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Random;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader =
                new BufferedReader(new InputStreamReader(System.in));

        String input = reader.readLine();

        Rank[] ranks = Rank.values();

        System.out.println(input + ":");
        for (Rank rank : ranks) {
            System.out.println(rank);
        }
    }
}
