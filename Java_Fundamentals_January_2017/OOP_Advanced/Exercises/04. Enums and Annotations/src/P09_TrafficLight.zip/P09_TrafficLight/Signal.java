package P09_TrafficLight;

public enum Signal {
    RED, GREEN, YELLOW;

}
