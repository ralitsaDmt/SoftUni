package pr0304Barracks.core;

import pr0304Barracks.contracts.Repository;
import pr0304Barracks.contracts.UnitFactory;
import pr0304Barracks.core.commands.*;

public class CommandInterpreter {
    private Repository repository;
    private UnitFactory unitFactory;

    public CommandInterpreter(Repository repository, UnitFactory unitFactory) {
        this.repository = repository;
        this.unitFactory = unitFactory;
    }

    public String interpretCommand(String[] data, String commandName) throws IllegalAccessException, ClassNotFoundException, InstantiationException {
        Command command = parseCommand(data, commandName);
        String result = command.execute();
        return result;
    }

    private Command parseCommand(String[] data, String command) {
        switch (command) {
            case "add":
                return new AddUnitCommand(data, this.repository, this.unitFactory);
            case "report":
                return new ReportCommand(data, this.repository, this.unitFactory);
            case "fight":
                return new FightCommand(data, this.repository, this.unitFactory);
            case "retire":
                return new Retire(data, this.repository, this.unitFactory);
        }
        return null;
    }
}
