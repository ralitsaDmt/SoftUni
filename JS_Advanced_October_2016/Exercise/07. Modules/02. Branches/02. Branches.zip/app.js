import { Employee } from './employee';
import { Branch } from './branch';

result.Employee = Employee;
result.Branch = Branch;
