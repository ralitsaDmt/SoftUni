let Person = require('./person');
let Post = require('./post');

result.Person = Person;
result.Post = Post;