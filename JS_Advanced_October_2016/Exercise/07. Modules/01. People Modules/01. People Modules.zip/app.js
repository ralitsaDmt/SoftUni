import { Employee } from './employee';
import { Junior } from './junior';
import { Senior } from './senior';
import { Manager } from './manager';


result.Employee = Employee;
result.Junior = Junior;
result.Senior = Senior;
result.Manager = Manager;