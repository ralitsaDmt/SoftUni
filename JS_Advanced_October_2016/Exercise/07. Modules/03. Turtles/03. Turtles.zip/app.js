
import { Turtle } from './turtle';
import { WaterTurtle } from './water-turtle';
import { GalapagosTurtle } from './galapagos-turtle';
import { EvkodianTurtle } from './evkodian-turtle';
import { NinjaTurtle } from './ninja-turtle';
//
// let Turtle = require('./turtle');
// let WaterTurtle = require('./water-turtle');
// let GalapagosTurtle = require('./galapagos-turtle');
// let EvkodianTurtle= require('./evkodian-turtle');
// let NinjaTurtle = require('./ninja-turtle');

result.Turtle = Turtle;
result.WaterTurtle = WaterTurtle;
result.GalapagosTurtle = GalapagosTurtle;
result.EvkodianTurtle = EvkodianTurtle;
result.NinjaTurtle = NinjaTurtle;
//
// let wTurtle = new WaterTurtle('name', 2, 'm', 'pool');
// let gTurtle = new GalapagosTurtle('name', 2, 'm');
// let eTurtle = new WaterTurtle('name', 2, 'm', 23);
// let nTurtle = new WaterTurtle('name', 2, 'm', 'pink', 'sword');